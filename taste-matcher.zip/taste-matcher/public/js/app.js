const IMAGE_BASE = 'https://image.tmdb.org/t/p/w342';
const defaultMessage = `
  <section class="hero">
    <div class="hero-badge">Taste Matcher · beta</div>
    <h2 class="hero-title">
      Turn your chaotic watchlist into a<br/>
      <span>perfectly ranked queue.</span>
    </h2>
    <p class="hero-subtitle">
      Built from your Letterboxd ratings + TMDb data. Use the actions above to explore:
    </p>
    <ul class="hero-list">
      <li>
        <span>🎬</span>
        <div>
          <strong>Ranked Watchlist</strong>
          <p>Every film in your watchlist ordered by how much you’ll probably love it.</p>
        </div>
      </li>
      <li>
        <span>🔁</span>
        <div>
          <strong>Ranked Rewatches</strong>
          <p>Your favourites, sorted by which are most worth revisiting right now.</p>
        </div>
      </li>
      <li>
        <span>📊</span>
        <div>
          <strong>Genre Profile</strong>
          <p>See which genres you actually reward with the highest ratings.</p>
        </div>
      </li>
    </ul>
    <p class="hero-footer">
      Start with <strong>“Show Ranked Watchlist”</strong> to see what you should watch tonight.
    </p>
  </section>
`;


let allRecommendations = [];
let currentGenreTitles = []; // for searching inside a genre

function setOutput(html) {
  document.getElementById('output').innerHTML = html;
}

function goHome() {
  setOutput(defaultMessage);
}

document.getElementById('backButton').addEventListener('click', goHome);

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/* -------- Reload watchlist.csv from /data -------- */

async function reloadWatchlist() {
  setOutput('<p class="summary">Reloading data/watchlist.csv and recalculating overlap + rankings…</p>');
  try {
    const res = await fetch('/api/reload-watchlist', {
      method: 'POST'
    });
    const data = await res.json();

    if (data.error) {
      alert('Error: ' + data.error);
      setOutput('<p class="summary">Failed to reload watchlist.</p>');
      return;
    }

    alert(
      'Watchlist reloaded from data/watchlist.csv. ' +
        'Watchlist items: ' +
        data.watchlistCount +
        ', rewatches: ' +
        data.overlapCount +
        '.'
    );

    // After reloading, immediately show updated ranked watchlist
    loadRecommendations();
  } catch (err) {
    console.error(err);
    alert('Failed to reload watchlist.');
    setOutput('<p class="summary">Failed to reload watchlist.</p>');
  }
}

async function resetState() {
  setOutput('<p class="summary">Resetting state back to ratings.csv + watchlist.csv…</p>');
  try {
    const res = await fetch('/api/reset-state', {
      method: 'POST'
    });
    const data = await res.json();

    if (data.error) {
      alert('Error: ' + data.error);
      setOutput('<p class="summary">Failed to reset state.</p>');
      return;
    }

    alert(
      'State reset to CSV.\n' +
        'Ratings: ' +
        data.ratingsCount +
        ', watchlist items: ' +
        data.watchlistCount +
        ', rewatches: ' +
        data.overlapCount +
        '.'
    );

    // After resetting, show fresh ranked watchlist
    loadRecommendations();
  } catch (err) {
    console.error(err);
    alert('Failed to reset state.');
    setOutput('<p class="summary">Failed to reset state.</p>');
  }
}

/* ------------------- RANKED REWATCHES ----------------------- */

async function loadRewatchRanking() {
  setOutput('<p class="summary">Loading ranked rewatches...</p>');
  const res = await fetch('/api/rewatch-ranking');
  const data = await res.json();

  const items = data.items || [];
  if (!items.length) {
    setOutput('<p class="summary">No rewatches detected or none available to rank.</p>');
    return;
  }

  let html = '<h3>Ranked Rewatches</h3>';
  html +=
    '<p class="summary">' +
    'Rewatches found: ' +
    data.count +
    '. ' +
    'Rated titles used for taste: ' +
    data.usedRatings +
    '.</p>';

  html += '<div class="cards">';

  items.forEach((r, i) => {
    const posterUrl = r.posterPath ? IMAGE_BASE + r.posterPath : null;
    const ratingText =
      typeof r.tmdbRating === 'number' ? r.tmdbRating.toFixed(1) : r.tmdbRating || '';
    const matchPercent = Math.round(r.rewatchScore * 100);

    html += '<div class="card">';
    if (posterUrl) {
      html +=
        '<img class="poster" src="' +
        posterUrl +
        '" alt="Poster of ' +
        escapeHtml(r.title) +
        '">';
    } else {
      html += '<div class="no-poster">No poster<br>available</div>';
    }
    html += '<div class="card-main">';
    html += '<div>';
    html += '<div class="title-row">';
    html += '<div class="title">' + escapeHtml(r.title) + '</div>';
    if (r.year) {
      html += '<div class="year">(' + escapeHtml(r.year) + ')</div>';
    }
    html += '</div>'; // title-row

    if (r.genres && r.genres.length) {
      html += '<div class="genres">' + escapeHtml(r.genres.join(', ')) + '</div>';
    }

    html += '<div class="meta">';
    if (ratingText) {
      html += '<span>TMDb: ' + ratingText + '/10</span>';
    }
    html += '<span>Your rating: ' + r.userRating + '</span>';
    html += '<span>Rewatch score: ' + r.rewatchScore.toFixed(3) + '</span>';
    html += '</div>';

    if (r.letterboxdUrl) {
      html +=
        '<div style="font-size:11px;">Source: <a class="movie-link" href="' +
        escapeHtml(r.letterboxdUrl) +
        '" target="_blank" rel="noopener noreferrer">Letterboxd entry</a></div>';
    }

    html += '</div>'; // top info

    html += '<div class="priority-row">';
    html += '<div class="priority-label">Rewatch priority: ' + matchPercent + '%</div>';
    html +=
      '<div class="bar-wrap"><div class="bar-fill" style="width:' +
      matchPercent +
      '%;"></div></div>';
    html += '<div class="priority-text">Rewatch rank #' + (i + 1) + '.</div>';
    html += '</div>';

    html += '</div>'; // card-main
    html += '</div>'; // card
  });

  html += '</div>'; // cards
  setOutput(html);
}

/* ------------------- GENRE PROFILE ------------------- */

async function loadGenreProfile() {
  setOutput(
    '<p class="summary">Building genre profile (this may take a little while the first time)...</p>'
  );
  const res = await fetch('/api/genre-profile');
  const data = await res.json();

  const stats = data.genreStats || {};
  const profile = data.genreProfile || {};
  const used = data.usedRatings || 0;

  const entries = Object.keys(stats).map((id) => {
    const s = stats[id];
    const avg = profile[id] || 0;
    return {
      id,
      name: s.name,
      avg,
      count: s.count
    };
  });

  if (!entries.length) {
    setOutput('<p>No genre data available.</p>');
    return;
  }

  entries.sort((a, b) => b.avg - a.avg);
  const maxAvg = Math.max.apply(
    null,
    entries.map((e) => e.avg)
  );

  let html = '<h3>Genre Profile</h3>';
  html +=
    '<p class="summary">Based on all ' +
    used +
    ' rated titles. Click a genre card to see the movies/series you rated in that genre.</p>';

  html += '<div class="genre-grid">';
  entries.forEach((e) => {
    const percent = maxAvg > 0 ? Math.round((e.avg / maxAvg) * 100) : 0;

    html += '<div class="genre-card" onclick="loadGenreTitles(' + e.id + ')">';
    html += '<div class="genre-name">' + escapeHtml(e.name) + '</div>';
    html += '<div>Smoothed average rating: ' + e.avg.toFixed(2) + ' / 5</div>';
    html += '<div>Rated titles in this genre: ' + e.count + '</div>';
    html +=
      '<div class="genre-bar-wrap"><div class="genre-bar-fill" style="width:' +
      percent +
      '%;"></div></div>';
    html += '</div>';
  });
  html += '</div>';

  setOutput(html);
}

async function loadGenreTitles(genreId) {
  setOutput('<p class="summary">Loading titles for this genre...</p>');
  const res = await fetch('/api/genre-titles/' + genreId);
  const data = await res.json();

  currentGenreTitles = data.items || [];
  const name = data.genreName || 'Selected genre';

  if (!currentGenreTitles.length) {
    setOutput(
      '<h3>' + escapeHtml(name) + '</h3><p class="summary">No rated titles found in this genre.</p>'
    );
    return;
  }

  let html = '<h3>' + escapeHtml(name) + ' – rated titles</h3>';
  html +=
    '<p class="summary">These are the movies/series you have rated that belong to this genre. ' +
    'Their ratings were used to learn your taste profile.</p>';

  html += `
    <div class="search-wrap">
      <input
        id="genreTitlesSearch"
        type="text"
        placeholder="Search within this genre by title..."
      />
    </div>
    <div id="genreTitlesCards" class="cards"></div>
  `;

  setOutput(html);

  const searchInput = document.getElementById('genreTitlesSearch');
  const cardsDiv = document.getElementById('genreTitlesCards');

  function renderGenreTitles(list) {
    if (!list.length) {
      cardsDiv.innerHTML =
        '<p class="summary">No titles match your search in this genre.</p>';
      return;
    }

    cardsDiv.innerHTML = list
      .map((r) => {
        const posterUrl = r.posterPath ? IMAGE_BASE + r.posterPath : null;
        const ratingText =
          typeof r.tmdbRating === 'number' ? r.tmdbRating.toFixed(1) : r.tmdbRating || '';

        return `
          <div class="card">
            ${
              posterUrl
                ? `<img class="poster" src="${posterUrl}" alt="Poster of ${escapeHtml(
                    r.title
                  )}">`
                : `<div class="no-poster">No poster<br>available</div>`
            }
            <div class="card-main">
              <div>
                <div class="title-row">
                  <div class="title">${escapeHtml(r.title)}</div>
                  ${
                    r.year
                      ? `<div class="year">(${escapeHtml(r.year)})</div>`
                      : ''
                  }
                </div>
                ${
                  r.genres && r.genres.length
                    ? `<div class="genres">${escapeHtml(r.genres.join(', '))}</div>`
                    : ''
                }
                <div class="meta">
                  ${ratingText ? `<span>TMDb: ${ratingText}/10</span>` : ''}
                  <span>Your rating: ${r.userRating}</span>
                </div>
                ${
                  r.letterboxdUrl
                    ? `<div style="font-size:11px;">Source: <a class="movie-link" href="${escapeHtml(
                        r.letterboxdUrl
                      )}" target="_blank" rel="noopener noreferrer">Letterboxd entry</a></div>`
                    : ''
                }
              </div>
            </div>
          </div>
        `;
      })
      .join('');
  }

  renderGenreTitles(currentGenreTitles);

  searchInput.addEventListener('input', () => {
    const q = searchInput.value.toLowerCase().trim();
    if (!q) {
      renderGenreTitles(currentGenreTitles);
      return;
    }
    const filtered = currentGenreTitles.filter((r) =>
      (r.title || '').toLowerCase().includes(q)
    );
    renderGenreTitles(filtered);
  });
}

/* ------------------- RECOMMENDATIONS ----------------- */

function attachMarkWatchedHandlers() {
  const cardsDiv = document.getElementById('recsCards');
  if (!cardsDiv) return;
  const btns = cardsDiv.querySelectorAll('.mark-watched-btn');
  btns.forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      const b = e.currentTarget;
      const url = b.dataset.url || '';
      const title = b.dataset.title || '';
      const year = b.dataset.year ? parseInt(b.dataset.year, 10) : null;

      if (!url) {
        alert('No Letterboxd URL found for this title.');
        return;
      }

      const ratingStr = window.prompt(`Your rating for "${title}" (0–5):`);
      if (ratingStr == null) return;
      const rating = parseFloat(ratingStr);
      if (isNaN(rating) || rating < 0 || rating > 5) {
        alert('Invalid rating. Please enter a number from 0 to 5.');
        return;
      }

      try {
        const res = await fetch('/api/mark-watched', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ letterboxdUrl: url, rating, title, year })
        });
        const data = await res.json();
        if (data.error) {
          alert('Error: ' + data.error);
        } else {
          alert('Saved. Updating recommendations.');
          loadRecommendations();
        }
      } catch (err) {
        console.error(err);
        alert('Failed to mark as watched.');
      }
    });
  });
}

function attachRemoveWatchlistHandlers() {
  const cardsDiv = document.getElementById('recsCards');
  if (!cardsDiv) return;
  const btns = cardsDiv.querySelectorAll('.remove-watchlist-btn');
  btns.forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      const b = e.currentTarget;
      const url = b.dataset.url || '';
      const title = b.dataset.title || '';

      if (!url) {
        alert('No Letterboxd URL found for this title.');
        return;
      }

      const confirmRemove = window.confirm(
        `Remove "${title}" from your watchlist? This is permanent for this CSV snapshot.`
      );
      if (!confirmRemove) return;

      try {
        const res = await fetch('/api/remove-from-watchlist', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ letterboxdUrl: url })
        });
        const data = await res.json();
        if (data.error) {
          alert('Error: ' + data.error);
        } else {
          alert('Removed from watchlist. Updating recommendations.');
          loadRecommendations();
        }
      } catch (err) {
        console.error(err);
        alert('Failed to remove from watchlist.');
      }
    });
  });
}

function renderRecommendations(list) {
  const cardsDiv = document.getElementById('recsCards');
  if (!cardsDiv) return;

  if (!list || !list.length) {
    cardsDiv.innerHTML =
      '<p class="summary">No recommendations to show. Check that watchlist.csv is present.</p>';
    return;
  }

  cardsDiv.innerHTML = list
    .map((r) => {
      const matchPercent = Math.round(r.predictedScore * 100);
      const rank = r.globalRank != null ? r.globalRank : allRecommendations.indexOf(r) + 1;

      const posterUrl = r.posterPath ? IMAGE_BASE + r.posterPath : null;
      const ratingText =
        typeof r.tmdbRating === 'number' ? r.tmdbRating.toFixed(1) : r.tmdbRating || '';
      const userGenreScore =
        typeof r.userGenreScore === 'number'
          ? r.userGenreScore.toFixed(2)
          : r.userGenreScore;

      return `
        <div class="card">
          ${
            posterUrl
              ? `<img class="poster" src="${posterUrl}" alt="Poster of ${escapeHtml(
                  r.title
                )}">`
              : `<div class="no-poster">No poster<br>available</div>`
          }
          <div class="card-main">
            <div>
              <div class="title-row">
                <div class="title">${escapeHtml(r.title)}</div>
                ${
                  r.year
                    ? `<div class="year">(${escapeHtml(r.year)})</div>`
                    : ''
                }
              </div>
              ${
                r.genres && r.genres.length
                  ? `<div class="genres">${escapeHtml(r.genres.join(', '))}</div>`
                  : ''
              }
              <div class="meta">
                ${ratingText ? `<span>TMDb: ${ratingText}/10</span>` : ''}
                <span>Smoothed genre rating: ${userGenreScore}</span>
                <span>Model score: ${r.predictedScore.toFixed(3)}</span>
              </div>
              ${
                r.letterboxdUrl
                  ? `<div style="font-size:11px;">Source: <a class="movie-link" href="${escapeHtml(
                      r.letterboxdUrl
                    )}" target="_blank" rel="noopener noreferrer">Letterboxd entry</a></div>`
                  : ''
              }
            </div>
            <div class="priority-row">
              <div class="priority-label">Match with your taste: ${matchPercent}%</div>
              <div class="bar-wrap"><div class="bar-fill" style="width:${matchPercent}%;"></div></div>
              <div class="priority-text">Rank #${rank} in your current watchlist.</div>
              <div style="margin-top:6px; display:flex; flex-wrap:wrap; gap:6px;">
                ${
                  r.letterboxdUrl
                    ? `<button class="small-btn mark-watched-btn"
                         data-url="${escapeHtml(r.letterboxdUrl)}"
                         data-title="${escapeHtml(r.title)}"
                         data-year="${escapeHtml(r.year || '')}">
                         Mark watched & rate
                       </button>
                       <button class="small-btn remove-watchlist-btn"
                         data-url="${escapeHtml(r.letterboxdUrl)}"
                         data-title="${escapeHtml(r.title)}">
                         Remove from watchlist
                       </button>`
                    : ''
                }
              </div>
            </div>
          </div>
        </div>
      `;
    })
    .join('');

  attachMarkWatchedHandlers();
  attachRemoveWatchlistHandlers();
}

async function loadRecommendations() {
  setOutput('<p class="summary">Calculating recommendations (first call may take a bit)...</p>');
  const res = await fetch('/api/recommendations');
  const data = await res.json();

  allRecommendations = data.recommendations || [];
  if (!allRecommendations.length) {
    setOutput('<p>No recommendations computed.</p>');
    return;
  }

  allRecommendations.forEach((r, idx) => {
    r.globalRank = idx + 1;
  });

  let html = '<h3>Ranked Watchlist</h3>';
  html +=
    '<p class="summary">' +
    'Total ratings: ' +
    data.totalRatings +
    ' (all used for taste profile). ' +
    'Total watchlist items being ranked (after removing rewatches): ' +
    data.totalWatchlist +
    '. ' +
    'Rewatches removed: ' +
    data.overlapCount +
    '.' +
    '</p>';

    html += `
    <div class="search-wrap">
      <input
        id="recsSearch"
        type="text"
        placeholder="Search by title or genre..."
      />
    </div>

    <div class="filters-row">
      <input
        id="filterYear"
        type="text"
        class="filter-input"
        placeholder="Year (e.g. 2019)"
      />
      <input
        id="filterDecade"
        type="text"
        class="filter-input"
        placeholder="Decade (e.g. 1990s)"
      />
      <select id="filterDirector" class="filter-select">
        <option value="all">All directors</option>
        <option value="watched">Only watched directors</option>
        <option value="unwatched">Only unwatched directors</option>
      </select>
      <button class="pill-btn" id="applyFiltersBtn" type="button">Apply filters</button>
      <button class="pill-btn ghost" id="clearFiltersBtn" type="button">Clear filters</button>
    </div>

    <div id="recsCards" class="cards"></div>
  `;

  setOutput(html);

  const searchInput = document.getElementById('recsSearch');
  const yearInput = document.getElementById('filterYear');
  const decadeInput = document.getElementById('filterDecade');
  const directorSelect = document.getElementById('filterDirector');
  const applyFiltersBtn = document.getElementById('applyFiltersBtn');
  const clearFiltersBtn = document.getElementById('clearFiltersBtn');

  function applyAllFilters() {
    const q = (searchInput.value || '').toLowerCase().trim();
    const yearStr = (yearInput.value || '').trim();
    const decadeStr = (decadeInput.value || '').trim();
    const dirMode = directorSelect.value;

    let filtered = allRecommendations.slice();

    // Search by title/genre
    if (q) {
      filtered = filtered.filter((r) => {
        const inTitle = (r.title || '').toLowerCase().includes(q);
        const inGenres = (r.genres || []).some((g) => (g || '').toLowerCase().includes(q));
        return inTitle || inGenres;
      });
    }

    // Filter by year
    if (yearStr) {
      const year = parseInt(yearStr, 10);
      if (isNaN(year) || year < 1888 || year > 2100) {
        setOutput('<p class="summary">No such Year exists.</p>');
        return;
      }
      filtered = filtered.filter((r) => parseInt(r.year, 10) === year);
      if (!filtered.length) {
        setOutput(
          "<p class='summary'>There aren't any films in your watchlist from this particular year.</p>"
        );
        return;
      }
    }

    // Filter by decade (e.g. "1990s")
    if (decadeStr) {
      const match = decadeStr.match(/^(\d{4})s$/i);
      if (!match) {
        setOutput('<p class="summary">No such Year exists.</p>');
        return;
      }
      const decadeStart = parseInt(match[1], 10);
      if (isNaN(decadeStart) || decadeStart < 1880 || decadeStart > 2100) {
        setOutput('<p class="summary">No such Year exists.</p>');
        return;
      }
      filtered = filtered.filter((r) => {
        const y = parseInt(r.year, 10);
        return y >= decadeStart && y <= decadeStart + 9;
      });
      if (!filtered.length) {
        setOutput(
          "<p class='summary'>There aren't any films in your watchlist from this particular year.</p>"
        );
        return;
      }
    }

    // Filter by watched/unwatched directors
    if (dirMode === 'watched') {
      filtered = filtered.filter((r) => r.hasWatchedDirector);
    } else if (dirMode === 'unwatched') {
      filtered = filtered.filter((r) => !r.hasWatchedDirector);
    }

    const container = document.getElementById('recsCards');
    if (!filtered.length) {
      container.innerHTML = '<p class="summary">No titles match the current filters.</p>';
    } else {
      renderRecommendations(filtered);
    }
  }

  searchInput.addEventListener('input', applyAllFilters);
  applyFiltersBtn.addEventListener('click', applyAllFilters);
  clearFiltersBtn.addEventListener('click', () => {
    searchInput.value = '';
    yearInput.value = '';
    decadeInput.value = '';
    directorSelect.value = 'all';
    renderRecommendations(allRecommendations);
  });

  renderRecommendations(allRecommendations);
}

/* ------------------- MANUAL MUTATIONS ----------------- */

async function promptAddRating() {
  const tmdbInput = window.prompt('TMDb URL or ID (optional – recommended):');
  const title = window.prompt(
    'Title of the film/series (will be overridden if TMDb is provided):'
  );
  const yearStr = window.prompt('Year (optional):');
  const year = yearStr ? parseInt(yearStr, 10) : null;
  const lbUrl = window.prompt('Letterboxd URL (optional – for source display):');
  const ratingStr = window.prompt('Your rating (0–5):');
  if (ratingStr == null) return;
  const rating = parseFloat(ratingStr);
  if (isNaN(rating) || rating < 0 || rating > 5) {
    alert('Invalid rating. Please enter a number from 0 to 5.');
    return;
  }

  try {
    const res = await fetch('/api/add-rating', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, year, letterboxdUrl: lbUrl, rating, tmdbInput })
    });
    const data = await res.json();
    if (data.error) {
      alert('Error: ' + data.error);
    } else {
      alert(
        'Rating added. Click "Ranked Watchlist" or "Ranked Rewatches" again to see updated results.'
      );
    }
  } catch (err) {
    console.error(err);
    alert('Failed to add rating.');
  }
}

async function promptAddToWatchlist() {
  const tmdbInput = window.prompt('TMDb URL or ID (optional – recommended):');
  const title = window.prompt(
    'Title of the film/series (will be overridden if TMDb is provided):'
  );
  const yearStr = window.prompt('Year (optional):');
  const year = yearStr ? parseInt(yearStr, 10) : null;
  const lbUrl = window.prompt('Letterboxd URL (required – used as source):');
  if (!lbUrl) {
    alert('Letterboxd URL is required.');
    return;
  }

  try {
    const res = await fetch('/api/add-to-watchlist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, year, letterboxdUrl: lbUrl, tmdbInput })
    });
    const data = await res.json();
    if (data.error) {
      if (data.rewatch) {
        alert('Note: ' + data.error);
      } else {
        alert('Error: ' + data.error);
      }
    } else {
      alert('Added to watchlist. Re-open "Ranked Watchlist" to see where it lands.');
      loadRecommendations();
    }
  } catch (err) {
    console.error(err);
    alert('Failed to add to watchlist.');
  }
}

async function exportRankedWatchlist() {
  const includeChoice = window.confirm(
    'Include rewatches in the exported list?\n\n' +
      'OK  = Include rewatches (they will be ranked alongside the rest of your watchlist).\n' +
      'Cancel = Export WITHOUT rewatches.\n\n' +
      'You will get a second prompt if you want to cancel the export entirely.'
  );

  let includeRewatches;

  if (includeChoice) {
    includeRewatches = 'true';
  } else {
    const proceedWithout = window.confirm(
      'Export the ranked watchlist WITHOUT rewatches?\n\n' +
        'OK     = Export without rewatches.\n' +
        'Cancel = Abort (do not export anything).'
    );

    if (!proceedWithout) {
      alert('Export cancelled.');
      return;
    }

    includeRewatches = 'false';
  }

  try {
    const res = await fetch(
      '/api/export-ranked-watchlist?includeRewatches=' + includeRewatches
    );
    const data = await res.json();
    if (data.error) {
      alert('Error: ' + data.error);
      return;
    }
    alert(
      'Exported ranked watchlist as "' +
        data.file +
        '" in the "exported" folder inside your Taste Matcher directory.\n\n' +
        (includeRewatches === 'true'
          ? 'Rewatches WERE included in this export.'
          : 'Rewatches were NOT included in this export.')
    );
  } catch (err) {
    console.error(err);
    alert('Failed to export ranked watchlist.');
  }
}

// initial state
goHome();

require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

const app = express();
const PORT = process.env.PORT || 3000;

const TMDB_API_KEY = process.env.TMDB_API_KEY;
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

if (!TMDB_API_KEY) {
  console.warn('⚠️ TMDB_API_KEY is not set in .env – TMDb requests will fail.');
}

// Data + cache holders
let ratings = [];          // ALL ratings (including rewatches)
let watchlist = [];        // Watchlist with rewatches removed
let overlapItems = [];     // Movies that are both in ratings and watchlist (rewatches)

// In-memory TMDb cache
const movieCache = new Map();

// Derived caches in memory
let cachedGenreProfile = null;
let cachedOverlapDetails = null;
let cachedRecommendations = null;

// Persistent cache files
const CACHE_DIR = path.join(__dirname, 'cache');
const TMDB_CACHE_FILE = path.join(CACHE_DIR, 'tmdb_cache.json');
const DERIVED_CACHE_FILE = path.join(CACHE_DIR, 'derived_cache.json');

/* ---------------------------------------------------
   0. CACHE UTILITIES
--------------------------------------------------- */

function ensureCacheDir() {
  if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
  }
}

// Load TMDb cache from disk into movieCache
function loadMovieCacheFromDisk() {
  ensureCacheDir();
  if (!fs.existsSync(TMDB_CACHE_FILE)) {
    console.log('TMDb cache file not found, will build it on first run.');
    return;
  }
  try {
    const raw = fs.readFileSync(TMDB_CACHE_FILE, 'utf-8');
    const obj = JSON.parse(raw);
    Object.keys(obj).forEach(key => {
      movieCache.set(key, obj[key]);
    });
    console.log(`Loaded TMDb cache from disk with ${movieCache.size} entries.`);
  } catch (err) {
    console.warn('Failed to load TMDb cache from disk:', err.message);
  }
}

// Save movieCache to disk
function saveMovieCacheToDisk() {
  ensureCacheDir();
  try {
    const obj = {};
    for (const [key, value] of movieCache.entries()) {
      obj[key] = value;
    }
    fs.writeFileSync(TMDB_CACHE_FILE, JSON.stringify(obj, null, 2), 'utf-8');
    // console.log('TMDb cache saved to disk.');
  } catch (err) {
    console.warn('Failed to save TMDb cache to disk:', err.message);
  }
}

// Load derived caches (genre profile, overlap, recs) from disk
function loadDerivedCacheFromDisk() {
  ensureCacheDir();
  if (!fs.existsSync(DERIVED_CACHE_FILE)) {
    console.log('Derived cache file not found, will build it on first run.');
    return;
  }
  try {
    const raw = fs.readFileSync(DERIVED_CACHE_FILE, 'utf-8');
    const obj = JSON.parse(raw);
    if (obj.genreProfile) {
      cachedGenreProfile = obj.genreProfile;
    }
    if (obj.overlapDetails) {
      cachedOverlapDetails = obj.overlapDetails;
    }
    if (obj.recommendations) {
      cachedRecommendations = obj.recommendations;
    }
    console.log('Loaded derived caches (genre profile / overlap / recommendations) from disk.');
  } catch (err) {
    console.warn('Failed to load derived cache from disk:', err.message);
  }
}

// Save derived caches to disk
function saveDerivedCacheToDisk() {
  ensureCacheDir();
  try {
    const obj = {
      genreProfile: cachedGenreProfile,
      overlapDetails: cachedOverlapDetails,
      recommendations: cachedRecommendations
    };
    fs.writeFileSync(DERIVED_CACHE_FILE, JSON.stringify(obj, null, 2), 'utf-8');
    // console.log('Derived caches saved to disk.');
  } catch (err) {
    console.warn('Failed to save derived cache to disk:', err.message);
  }
}

/* ---------------------------------------------------
   1. LOAD & CLEAN DATA FROM CSV
--------------------------------------------------- */

function loadRatingsFromCsv() {
  const filePath = path.join(__dirname, 'data', 'ratings.csv');

  if (!fs.existsSync(filePath)) {
    console.warn('⚠️ ratings.csv not found in /data');
    return [];
  }

  const raw = fs.readFileSync(filePath, 'utf-8');

  const records = parse(raw, {
    columns: true,
    skip_empty_lines: true
  });

  const list = records
    .map(row => {
      const ratingValue = parseFloat(row['Rating']);
      if (isNaN(ratingValue)) return null;

      return {
        title: row['Name'],
        year: row['Year'] ? parseInt(row['Year'], 10) : null,
        rating: ratingValue,
        url: row['Letterboxd URI']
      };
    })
    .filter(m => m && m.title && m.url);

  console.log(`Loaded ${list.length} rating entries from ratings.csv`);
  return list;
}

function loadWatchlistFromCsv() {
  const filePath = path.join(__dirname, 'data', 'watchlist.csv');

  if (!fs.existsSync(filePath)) {
    console.warn('⚠️ watchlist.csv not found in /data');
    return [];
  }

  const raw = fs.readFileSync(filePath, 'utf-8');

  const marker = 'Position,Name,Year,URL,Description';
  const idx = raw.indexOf(marker);

  if (idx === -1) {
    console.warn('⚠️ Could not find list header "Position,Name,Year,URL,Description" in watchlist.csv');
    return [];
  }

  const sliced = raw.slice(idx);

  const records = parse(sliced, {
    columns: true,
    skip_empty_lines: true
  });

  const list = records
    .map(row => {
      return {
        title: row['Name'],
        year: row['Year'] ? parseInt(row['Year'], 10) : null,
        url: row['URL']
      };
    })
    .filter(m => m.title && m.url);

  console.log(`Loaded ${list.length} watchlist entries from watchlist.csv`);
  return list;
}

// Find overlapping entries (rewatches)
function computeOverlapAndClean(ratingList, watchList) {
  const ratingByUrl = new Map();
  ratingList.forEach(r => {
    const u = (r.url || '').toLowerCase().trim();
    if (!u) return;
    if (!ratingByUrl.has(u)) ratingByUrl.set(u, r);
  });

  const watchByUrl = new Map();
  watchList.forEach(w => {
    const u = (w.url || '').toLowerCase().trim();
    if (!u) return;
    if (!watchByUrl.has(u)) watchByUrl.set(u, w);
  });

  const overlap = [];
  const overlapSet = new Set();

  ratingByUrl.forEach((ratingItem, url) => {
    if (watchByUrl.has(url)) {
      overlapSet.add(url);

      const watchItem = watchByUrl.get(url);
      overlap.push({
        url,
        title: ratingItem.title || watchItem.title,
        year: ratingItem.year || watchItem.year || null,
        rating: ratingItem.rating
      });
    }
  });

  const cleanedWatchlist = watchList.filter(
    w => !overlapSet.has((w.url || '').toLowerCase().trim())
  );

  console.log(
    `Found ${overlap.length} overlapping "rewatch" entries. ` +
    `Final counts: ${ratingList.length} ratings used for taste, ` +
    `${cleanedWatchlist.length} watchlist items to rank.`
  );

  return { cleanedWatchlist, overlap };
}

function loadAllData() {
  const rawRatings = loadRatingsFromCsv();
  const rawWatchlist = loadWatchlistFromCsv();

  const { cleanedWatchlist, overlap } = computeOverlapAndClean(
    rawRatings,
    rawWatchlist
  );

  ratings = rawRatings;
  watchlist = cleanedWatchlist;
  overlapItems = overlap;

  // Reset in-memory derived caches (disk caches are loaded separately)
  if (!cachedGenreProfile || !cachedRecommendations || !cachedOverlapDetails) {
    console.log('Derived cache not fully available, will build as needed.');
  }
}

/* ---------------------------------------------------
   2. TMDB HELPERS  (movie + TV fallback, with disk cache)
--------------------------------------------------- */

async function getMovieDetailsForItem(item) {
  if (!TMDB_API_KEY) {
    throw new Error('TMDB_API_KEY missing in .env');
  }

  const key = `${item.title}_${item.year || ''}`.toLowerCase();

  // In-memory cache first
  if (movieCache.has(key)) {
    return movieCache.get(key);
  }

  // 1) try movie search
  const movieSearchUrl = `${TMDB_BASE_URL}/search/movie`;
  const movieParams = {
    api_key: TMDB_API_KEY,
    query: item.title
  };
  if (item.year) {
    movieParams.year = item.year;
  }

  let results = [];
  try {
    const searchResp = await axios.get(movieSearchUrl, { params: movieParams });
    results = searchResp.data.results || [];
  } catch (e) {
    console.warn(`TMDb movie search failed for "${item.title}": ${e.message}`);
  }

  let detailUrl;
  let type = 'movie';

  // 2) if no movie found, try TV search
  if (!results.length) {
    const tvSearchUrl = `${TMDB_BASE_URL}/search/tv`;
    const tvParams = {
      api_key: TMDB_API_KEY,
      query: item.title
    };
    if (item.year) {
      tvParams.first_air_date_year = item.year;
    }

    const tvResp = await axios.get(tvSearchUrl, { params: tvParams });
    const tvResults = tvResp.data.results || [];

    if (!tvResults.length) {
      throw new Error(
        `No TMDb search result for "${item.title}" (${item.year || 'year unknown'})`
      );
    }

    const bestTv = tvResults[0];
    detailUrl = `${TMDB_BASE_URL}/tv/${bestTv.id}`;
    type = 'tv';
  } else {
    const bestMovie = results[0];
    detailUrl = `${TMDB_BASE_URL}/movie/${bestMovie.id}`;
  }

  const detailResp = await axios.get(detailUrl, {
    params: {
      api_key: TMDB_API_KEY,
      language: 'en-US'
    }
  });

  const movie = detailResp.data;
  movie.__type = type;

  // save to in-memory + disk cache
  movieCache.set(key, movie);
  saveMovieCacheToDisk();

  return movie;
}

/* ---------------------------------------------------
   3. GENRE PROFILE
--------------------------------------------------- */

async function buildGenreProfile() {
  // Use in-memory cache if already built
  if (cachedGenreProfile) return cachedGenreProfile;

  if (!ratings.length) {
    cachedGenreProfile = { genreProfile: {}, genreStats: {}, usedRatings: 0 };
    saveDerivedCacheToDisk();
    return cachedGenreProfile;
  }

  const genreStats = {};

  console.log(`Building genre profile using ALL ${ratings.length} rated titles...`);

  for (const item of ratings) {
    if (!item.rating) continue;

    try {
      const movie = await getMovieDetailsForItem(item);
      const movieGenres = movie.genres || [];

      movieGenres.forEach(g => {
        const id = g.id;
        if (!genreStats[id]) {
          genreStats[id] = {
            name: g.name,
            totalRating: 0,
            count: 0
          };
        }
        genreStats[id].totalRating += item.rating;
        genreStats[id].count += 1;
      });
    } catch (err) {
      console.warn(`Failed to fetch details for rated title "${item.title}": ${err.message}`);
    }
  }

  const genreProfile = {};
  Object.keys(genreStats).forEach(id => {
    const stat = genreStats[id];
    genreProfile[id] = stat.totalRating / stat.count;
  });

  cachedGenreProfile = {
    genreProfile,
    genreStats,
    usedRatings: ratings.length
  };

  saveDerivedCacheToDisk();
  return cachedGenreProfile;
}

/* ---------------------------------------------------
   4. OVERLAP / REWATCH DETAILS
--------------------------------------------------- */

async function buildOverlapDetails() {
  if (cachedOverlapDetails) return cachedOverlapDetails;

  const detailed = [];

  for (const item of overlapItems) {
    try {
      const movie = await getMovieDetailsForItem(item);
      const genres = movie.genres || [];

      detailed.push({
        title: movie.title || movie.name,
        year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
        tmdbId: movie.id,
        posterPath: movie.poster_path,
        genres: genres.map(g => g.name),
        tmdbRating: movie.vote_average,
        userRating: item.rating,
        letterboxdUrl: item.url
      });
    } catch (err) {
      console.warn(`Failed to fetch overlap details for "${item.title}": ${err.message}`);
    }
  }

  cachedOverlapDetails = detailed;
  saveDerivedCacheToDisk();
  return detailed;
}

/* ---------------------------------------------------
   5. RECOMMENDATIONS
--------------------------------------------------- */

async function calculateRecommendations() {
  if (cachedRecommendations) return cachedRecommendations;

  if (!ratings.length || !watchlist.length) {
    cachedRecommendations = {
      recommendations: [],
      usedRatings: 0,
      usedWatchlist: 0
    };
    saveDerivedCacheToDisk();
    return cachedRecommendations;
  }

  const { genreProfile } = await buildGenreProfile();

  console.log(`Calculating recommendations for ALL ${watchlist.length} watchlist titles...`);

  const recs = [];

  for (const item of watchlist) {
    try {
      const movie = await getMovieDetailsForItem(item);
      const genres = movie.genres || [];

      let sumGenreScore = 0;
      let countGenresFound = 0;

      genres.forEach(g => {
        const gScore = genreProfile[g.id];
        if (gScore !== undefined) {
          sumGenreScore += gScore;
          countGenresFound += 1;
        }
      });

      const userGenreScore =
        countGenresFound > 0 ? sumGenreScore / countGenresFound : 0;

      const tmdbScore = (movie.vote_average || 0) / 10;

      const predictedScore = userGenreScore * 0.7 + tmdbScore * 0.3;

      recs.push({
        title: movie.title || movie.name,
        year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
        tmdbId: movie.id,
        posterPath: movie.poster_path,
        genres: genres.map(g => g.name),
        tmdbRating: movie.vote_average,
        userGenreScore: Number(userGenreScore.toFixed(2)),
        predictedScore: Number(predictedScore.toFixed(3)),
        letterboxdUrl: item.url,
        overview: movie.overview
      });
    } catch (err) {
      console.warn(`Failed to fetch details for watchlist title "${item.title}": ${err.message}`);
    }
  }

  recs.sort((a, b) => b.predictedScore - a.predictedScore);

  cachedRecommendations = {
    recommendations: recs,
    usedRatings: ratings.length,
    usedWatchlist: watchlist.length
  };

  saveDerivedCacheToDisk();
  return cachedRecommendations;
}

/* ---------------------------------------------------
   6. STATIC FRONTEND
--------------------------------------------------- */

app.use(express.static(path.join(__dirname, 'public')));

/* ---------------------------------------------------
   7. API ROUTES
--------------------------------------------------- */

app.get('/api', (req, res) => {
  res.json({
    message: 'Taste Matcher API is running',
    note: 'Using full ratings.csv for taste + full watchlist.csv with rewatches removed. TMDb + taste model are cached on disk.',
    endpoints: [
      'GET /api/ratings',
      'GET /api/watchlist',
      'GET /api/overlap',
      'GET /api/genre-profile',
      'GET /api/genre-titles/:genreId',
      'GET /api/recommendations'
    ]
  });
});

app.get('/api/ratings', (req, res) => {
  res.json(ratings);
});

app.get('/api/watchlist', (req, res) => {
  res.json(watchlist);
});

app.get('/api/overlap', async (req, res) => {
  try {
    const items = await buildOverlapDetails();
    res.json({
      count: overlapItems.length,
      totalRatings: ratings.length,
      totalWatchlistAfterRemoval: watchlist.length,
      items
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build overlap details' });
  }
});

app.get('/api/genre-profile', async (req, res) => {
  try {
    const { genreProfile, genreStats, usedRatings } = await buildGenreProfile();
    res.json({
      usedRatings,
      genreProfile,
      genreStats
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build genre profile' });
  }
});

app.get('/api/genre-titles/:genreId', async (req, res) => {
  const genreId = parseInt(req.params.genreId, 10);
  if (isNaN(genreId)) {
    return res.status(400).json({ error: 'Invalid genre id' });
  }

  try {
    const { genreStats } = await buildGenreProfile();
    const genreInfo = genreStats[genreId];

    const items = [];

    for (const item of ratings) {
      try {
        const movie = await getMovieDetailsForItem(item);
        const genres = movie.genres || [];
        if (!genres.some(g => g.id === genreId)) continue;

        items.push({
          title: movie.title || movie.name,
          year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
          tmdbId: movie.id,
          posterPath: movie.poster_path,
          genres: genres.map(g => g.name),
          tmdbRating: movie.vote_average,
          userRating: item.rating,
          letterboxdUrl: item.url
        });
      } catch (err) {
        console.warn(`Failed to fetch details for genre-titles "${item.title}": ${err.message}`);
      }
    }

    res.json({
      genreId,
      genreName: genreInfo ? genreInfo.name : null,
      count: items.length,
      items
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build list of titles for this genre' });
  }
});

app.get('/api/recommendations', async (req, res) => {
  try {
    const { recommendations, usedRatings, usedWatchlist } = await calculateRecommendations();
    res.json({
      totalRatings: ratings.length,
      totalWatchlist: watchlist.length,
      overlapCount: overlapItems.length,
      usedRatings,
      usedWatchlist,
      recommendations
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to calculate recommendations' });
  }
});

/* ---------------------------------------------------
   8. STARTUP
--------------------------------------------------- */

// 1) Load caches from disk (if any)
loadMovieCacheFromDisk();
loadDerivedCacheFromDisk();

// 2) Load CSV data and overlap info
loadAllData();

app.listen(PORT, () => {
  console.log(`✅ Taste Matcher server listening on http://localhost:${PORT}`);
  console.log('Hint: delete the "cache" folder if you change ratings.csv or watchlist.csv and want to rebuild everything.');
});

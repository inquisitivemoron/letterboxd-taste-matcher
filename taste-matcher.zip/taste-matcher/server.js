require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

const app = express();
const PORT = process.env.PORT || 3000;

const TMDB_API_KEY = process.env.TMDB_API_KEY;
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

if (!TMDB_API_KEY) {
  console.warn('⚠️ TMDB_API_KEY is not set in .env – TMDb requests will fail.');
}

// Data + cache holders
let ratings = [];          // ALL ratings (including rewatches)
let watchlist = [];        // Watchlist with rewatches removed
let overlapItems = [];     // Movies that are both in ratings and watchlist (rewatches)

// In-memory TMDb cache
const movieCache = new Map();

// Derived caches in memory
let cachedTasteModel = null;        // extended taste model (genres, directors, keywords, etc.)
let cachedOverlapDetails = null;
let cachedRecommendations = null;

// Persistent cache files
const CACHE_DIR = path.join(__dirname, 'cache');
const TMDB_CACHE_FILE = path.join(CACHE_DIR, 'tmdb_cache.json');
const DERIVED_CACHE_FILE = path.join(CACHE_DIR, 'derived_cache.json');

/* ---------------------------------------------------
   0. CACHE UTILITIES
--------------------------------------------------- */

function ensureCacheDir() {
  if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
  }
}

// Load TMDb cache from disk into movieCache
function loadMovieCacheFromDisk() {
  ensureCacheDir();
  if (!fs.existsSync(TMDB_CACHE_FILE)) {
    console.log('TMDb cache file not found, will build it on first run.');
    return;
  }
  try {
    const raw = fs.readFileSync(TMDB_CACHE_FILE, 'utf-8');
    const obj = JSON.parse(raw);
    Object.keys(obj).forEach(key => {
      movieCache.set(key, obj[key]);
    });
    console.log(`Loaded TMDb cache from disk with ${movieCache.size} entries.`);
  } catch (err) {
    console.warn('Failed to load TMDb cache from disk:', err.message);
  }
}

// Save movieCache to disk
function saveMovieCacheToDisk() {
  ensureCacheDir();
  try {
    const obj = {};
    for (const [key, value] of movieCache.entries()) {
      obj[key] = value;
    }
    fs.writeFileSync(TMDB_CACHE_FILE, JSON.stringify(obj, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Failed to save TMDb cache to disk:', err.message);
  }
}

// Load derived caches (taste model, overlap, recs) from disk
function loadDerivedCacheFromDisk() {
  ensureCacheDir();
  if (!fs.existsSync(DERIVED_CACHE_FILE)) {
    console.log('Derived cache file not found, will build it on first run.');
    return;
  }
  try {
    const raw = fs.readFileSync(DERIVED_CACHE_FILE, 'utf-8');
    const obj = JSON.parse(raw);
    if (obj.tasteModel) {
      cachedTasteModel = obj.tasteModel;
    }
    if (obj.overlapDetails) {
      cachedOverlapDetails = obj.overlapDetails;
    }
    if (obj.recommendations) {
      cachedRecommendations = obj.recommendations;
    }
    console.log('Loaded derived caches (taste model / overlap / recommendations) from disk.');
  } catch (err) {
    console.warn('Failed to load derived cache from disk:', err.message);
  }
}

// Save derived caches to disk
function saveDerivedCacheToDisk() {
  ensureCacheDir();
  try {
    const obj = {
      tasteModel: cachedTasteModel,
      overlapDetails: cachedOverlapDetails,
      recommendations: cachedRecommendations
    };
    fs.writeFileSync(DERIVED_CACHE_FILE, JSON.stringify(obj, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Failed to save derived cache to disk:', err.message);
  }
}

/* ---------------------------------------------------
   1. LOAD & CLEAN DATA FROM CSV
--------------------------------------------------- */

function loadRatingsFromCsv() {
  const filePath = path.join(__dirname, 'data', 'ratings.csv');

  if (!fs.existsSync(filePath)) {
    console.warn('⚠️ ratings.csv not found in /data');
    return [];
  }

  const raw = fs.readFileSync(filePath, 'utf-8');

  const records = parse(raw, {
    columns: true,
    skip_empty_lines: true
  });

  const list = records
    .map(row => {
      const ratingValue = parseFloat(row['Rating']);
      if (isNaN(ratingValue)) return null;

      return {
        title: row['Name'],
        year: row['Year'] ? parseInt(row['Year'], 10) : null,
        rating: ratingValue,
        url: row['Letterboxd URI']
      };
    })
    .filter(m => m && m.title && m.url);

  console.log(`Loaded ${list.length} rating entries from ratings.csv`);
  return list;
}

function loadWatchlistFromCsv() {
  const filePath = path.join(__dirname, 'data', 'watchlist.csv');

  if (!fs.existsSync(filePath)) {
    console.warn('⚠️ watchlist.csv not found in /data');
    return [];
  }

  const raw = fs.readFileSync(filePath, 'utf-8');

  const marker = 'Position,Name,Year,URL,Description';
  const idx = raw.indexOf(marker);

  if (idx === -1) {
    console.warn('⚠️ Could not find list header "Position,Name,Year,URL,Description" in watchlist.csv');
    return [];
  }

  const sliced = raw.slice(idx);

  const records = parse(sliced, {
    columns: true,
    skip_empty_lines: true
  });

  const list = records
    .map(row => {
      return {
        title: row['Name'],
        year: row['Year'] ? parseInt(row['Year'], 10) : null,
        url: row['URL']
      };
    })
    .filter(m => m.title && m.url);

  console.log(`Loaded ${list.length} watchlist entries from watchlist.csv`);
  return list;
}

// Find overlapping entries (rewatches)
function computeOverlapAndClean(ratingList, watchList) {
  const ratingByUrl = new Map();
  ratingList.forEach(r => {
    const u = (r.url || '').toLowerCase().trim();
    if (!u) return;
    if (!ratingByUrl.has(u)) ratingByUrl.set(u, r);
  });

  const watchByUrl = new Map();
  watchList.forEach(w => {
    const u = (w.url || '').toLowerCase().trim();
    if (!u) return;
    if (!watchByUrl.has(u)) watchByUrl.set(u, w);
  });

  const overlap = [];
  const overlapSet = new Set();

  ratingByUrl.forEach((ratingItem, url) => {
    if (watchByUrl.has(url)) {
      overlapSet.add(url);

      const watchItem = watchByUrl.get(url);
      overlap.push({
        url,
        title: ratingItem.title || watchItem.title,
        year: ratingItem.year || watchItem.year || null,
        rating: ratingItem.rating
      });
    }
  });

  const cleanedWatchlist = watchList.filter(
    w => !overlapSet.has((w.url || '').toLowerCase().trim())
  );

  console.log(
    `Found ${overlap.length} overlapping "rewatch" entries. ` +
    `Final counts: ${ratingList.length} ratings used for taste, ` +
    `${cleanedWatchlist.length} watchlist items to rank.`
  );

  return { cleanedWatchlist, overlap };
}

function loadAllData() {
  const rawRatings = loadRatingsFromCsv();
  const rawWatchlist = loadWatchlistFromCsv();

  const { cleanedWatchlist, overlap } = computeOverlapAndClean(
    rawRatings,
    rawWatchlist
  );

  ratings = rawRatings;
  watchlist = cleanedWatchlist;
  overlapItems = overlap;

  if (!cachedTasteModel || !cachedRecommendations || !cachedOverlapDetails) {
    console.log('Derived cache not fully available, will build as needed.');
  }
}

/* ---------------------------------------------------
   2. HELPERS: REGION MAPPING
--------------------------------------------------- */

function mapCountryToRegion(isoCode) {
  if (!isoCode) return 'Other';
  const code = isoCode.toUpperCase();

  // Super simple mapping, enough to talk about "region-based preferences"
  const europe = ['FR', 'DE', 'IT', 'ES', 'GB', 'UK', 'PL', 'SE', 'NO', 'DK', 'FI', 'NL', 'BE', 'CZ', 'RU', 'GR', 'IE', 'PT', 'HU', 'RO', 'BG', 'AT', 'CH', 'TR'];
  const asia = ['JP', 'CN', 'KR', 'IN', 'HK', 'TW', 'TH', 'VN', 'ID', 'MY', 'PH', 'SG', 'PK', 'BD', 'LK'];
  const northAmerica = ['US', 'CA', 'MX'];
  const southAmerica = ['BR', 'AR', 'CL', 'CO', 'PE', 'VE', 'UY', 'EC', 'BO', 'PY'];
  const oceania = ['AU', 'NZ'];
  const africa = ['ZA', 'NG', 'EG', 'MA', 'KE', 'GH', 'DZ', 'TN'];

  if (europe.includes(code)) return 'Europe';
  if (asia.includes(code)) return 'Asia';
  if (northAmerica.includes(code)) return 'North America';
  if (southAmerica.includes(code)) return 'South America';
  if (oceania.includes(code)) return 'Oceania';
  if (africa.includes(code)) return 'Africa';
  return 'Other';
}

/* ---------------------------------------------------
   3. TMDB HELPERS  (movie + TV + credits + keywords)
--------------------------------------------------- */

// This function fetches details + credits + keywords and normalizes them
async function getMovieDetailsForItem(item) {
  if (!TMDB_API_KEY) {
    throw new Error('TMDB_API_KEY missing in .env');
  }

  const key = `${item.title}_${item.year || ''}`.toLowerCase();

  // In-memory cache first
  if (movieCache.has(key)) {
    return movieCache.get(key);
  }

  // 1) search as movie
  const movieSearchUrl = `${TMDB_BASE_URL}/search/movie`;
  const movieParams = {
    api_key: TMDB_API_KEY,
    query: item.title
  };
  if (item.year) {
    movieParams.year = item.year;
  }

  let results = [];
  try {
    const searchResp = await axios.get(movieSearchUrl, { params: movieParams });
    results = searchResp.data.results || [];
  } catch (e) {
    console.warn(`TMDb movie search failed for "${item.title}": ${e.message}`);
  }

  let detailUrl;
  let creditsUrl;
  let keywordsUrl;
  let type = 'movie';
  let selectedId;

  // 2) if no movie found, try TV search
  if (!results.length) {
    const tvSearchUrl = `${TMDB_BASE_URL}/search/tv`;
    const tvParams = {
      api_key: TMDB_API_KEY,
      query: item.title
    };
    if (item.year) {
      tvParams.first_air_date_year = item.year;
    }

    const tvResp = await axios.get(tvSearchUrl, { params: tvParams });
    const tvResults = tvResp.data.results || [];

    if (!tvResults.length) {
      throw new Error(
        `No TMDb search result for "${item.title}" (${item.year || 'year unknown'})`
      );
    }

    const bestTv = tvResults[0];
    selectedId = bestTv.id;
    detailUrl = `${TMDB_BASE_URL}/tv/${bestTv.id}`;
    creditsUrl = `${TMDB_BASE_URL}/tv/${bestTv.id}/credits`;
    keywordsUrl = `${TMDB_BASE_URL}/tv/${bestTv.id}/keywords`;
    type = 'tv';
  } else {
    const bestMovie = results[0];
    selectedId = bestMovie.id;
    detailUrl = `${TMDB_BASE_URL}/movie/${bestMovie.id}`;
    creditsUrl = `${TMDB_BASE_URL}/movie/${bestMovie.id}/credits`;
    keywordsUrl = `${TMDB_BASE_URL}/movie/${bestMovie.id}/keywords`;
  }

  // Fetch detail + credits + keywords in parallel
  const [detailResp, creditsResp, keywordsResp] = await Promise.all([
    axios.get(detailUrl, {
      params: {
        api_key: TMDB_API_KEY,
        language: 'en-US'
      }
    }),
    axios.get(creditsUrl, {
      params: {
        api_key: TMDB_API_KEY,
        language: 'en-US'
      }
    }).catch(() => ({ data: { cast: [], crew: [] } })), // be robust
    axios.get(keywordsUrl, {
      params: {
        api_key: TMDB_API_KEY
      }
    }).catch(() => ({ data: { keywords: [], results: [] } }))
  ]);

  const movie = detailResp.data;
  movie.__type = type;

  // Normalize year & decade
  const dateStr = movie.release_date || movie.first_air_date || '';
  let year = null;
  let decade = null;
  if (dateStr && dateStr.length >= 4) {
    year = parseInt(dateStr.slice(0, 4), 10);
    if (!isNaN(year)) {
      decade = Math.floor(year / 10) * 10; // e.g. 1970, 1980, 2010
    }
  }

  // Normalize countries
  const countries = (movie.production_countries || []).map(c => ({
    code: c.iso_3166_1,
    name: c.name,
    region: mapCountryToRegion(c.iso_3166_1)
  }));

  // Normalize collection (if any)
  const collection = movie.belongs_to_collection || null;
  const collectionId = collection ? collection.id : null;
  const collectionName = collection ? collection.name : null;

  // Normalize credits: directors + writers
  const credits = creditsResp.data || { cast: [], crew: [] };
  const crew = credits.crew || [];

  const directors = crew
    .filter(c => c.job === 'Director')
    .map(c => c.name);

  const writerJobs = [
    'Writer',
    'Screenplay',
    'Screenwriter',
    'Author',
    'Story',
    'Co-Writer'
  ];
  const writers = crew
    .filter(c => writerJobs.includes(c.job))
    .map(c => c.name);

  // Normalize keywords
  let keywords = [];
  if (movie.__type === 'movie') {
    // movie keywords: { keywords: [ {id,name} ] }
    const arr = keywordsResp.data && keywordsResp.data.keywords;
    if (Array.isArray(arr)) {
      keywords = arr.map(k => k.name);
    }
  } else {
    // tv keywords: { results: [ {id,name} ] }
    const arr = keywordsResp.data && keywordsResp.data.results;
    if (Array.isArray(arr)) {
      keywords = arr.map(k => k.name);
    }
  }

  movie.__meta = {
    id: selectedId,
    type,
    year,
    decade,
    countries,       // [{code,name,region}]
    collectionId,
    collectionName,
    directors,
    writers,
    keywords
  };

  movieCache.set(key, movie);
  saveMovieCacheToDisk();

  return movie;
}

/* ---------------------------------------------------
   4. TASTE MODEL (MULTI-DIMENSIONAL)
--------------------------------------------------- */

async function buildTasteModel() {
  // Use in-memory cache if already built
  if (cachedTasteModel) return cachedTasteModel;

  if (!ratings.length) {
    cachedTasteModel = {
      usedRatings: 0,
      genreStats: {},
      genreProfile: {},
      directorStats: {},
      directorProfile: {},
      writerStats: {},
      writerProfile: {},
      countryStats: {},
      countryProfile: {},
      regionStats: {},
      regionProfile: {},
      decadeStats: {},
      decadeProfile: {},
      keywordStats: {},
      keywordProfile: {},
      collectionStats: {},
      collectionProfile: {}
    };
    saveDerivedCacheToDisk();
    return cachedTasteModel;
  }

  console.log(`Building extended taste model using ALL ${ratings.length} rated titles...`);

  const genreStats = {};
  const directorStats = {};
  const writerStats = {};
  const countryStats = {};
  const regionStats = {};
  const decadeStats = {};
  const keywordStats = {};
  const collectionStats = {};

  for (const item of ratings) {
    if (!item.rating) continue;
    const userRating = item.rating;

    try {
      const movie = await getMovieDetailsForItem(item);
      const meta = movie.__meta || {};
      const movieGenres = movie.genres || [];

      // Genres
      movieGenres.forEach(g => {
        const id = g.id;
        if (!genreStats[id]) {
          genreStats[id] = {
            name: g.name,
            totalRating: 0,
            count: 0
          };
        }
        genreStats[id].totalRating += userRating;
        genreStats[id].count += 1;
      });

      // Directors
      (meta.directors || []).forEach(name => {
        if (!directorStats[name]) {
          directorStats[name] = { totalRating: 0, count: 0 };
        }
        directorStats[name].totalRating += userRating;
        directorStats[name].count += 1;
      });

      // Writers
      (meta.writers || []).forEach(name => {
        if (!writerStats[name]) {
          writerStats[name] = { totalRating: 0, count: 0 };
        }
        writerStats[name].totalRating += userRating;
        writerStats[name].count += 1;
      });

      // Countries / Regions
      (meta.countries || []).forEach(c => {
        if (c.code) {
          if (!countryStats[c.code]) {
            countryStats[c.code] = {
              name: c.name || c.code,
              totalRating: 0,
              count: 0
            };
          }
          countryStats[c.code].totalRating += userRating;
          countryStats[c.code].count += 1;
        }

        const region = c.region || 'Other';
        if (!regionStats[region]) {
          regionStats[region] = { totalRating: 0, count: 0 };
        }
        regionStats[region].totalRating += userRating;
        regionStats[region].count += 1;
      });

      // Decade
      if (meta.decade != null) {
        const d = meta.decade;
        if (!decadeStats[d]) {
          decadeStats[d] = { totalRating: 0, count: 0 };
        }
        decadeStats[d].totalRating += userRating;
        decadeStats[d].count += 1;
      }

      // Keywords
      (meta.keywords || []).forEach(k => {
        const key = k.toLowerCase();
        if (!keywordStats[key]) {
          keywordStats[key] = { totalRating: 0, count: 0 };
        }
        keywordStats[key].totalRating += userRating;
        keywordStats[key].count += 1;
      });

      // Collections
      if (meta.collectionId) {
        const cid = meta.collectionId;
        const cname = meta.collectionName || `Collection ${cid}`;
        if (!collectionStats[cid]) {
          collectionStats[cid] = { name: cname, totalRating: 0, count: 0 };
        }
        collectionStats[cid].totalRating += userRating;
        collectionStats[cid].count += 1;
      }
    } catch (err) {
      console.warn(`Failed to fetch details for rated title "${item.title}": ${err.message}`);
    }
  }

  // Helper to convert stats → average profile
  function buildProfileFromStats(statsObj) {
    const profile = {};
    Object.keys(statsObj).forEach(key => {
      const s = statsObj[key];
      profile[key] = s.totalRating / s.count;
    });
    return profile;
  }

  const genreProfile = buildProfileFromStats(genreStats);
  const directorProfile = buildProfileFromStats(directorStats);
  const writerProfile = buildProfileFromStats(writerStats);
  const countryProfile = buildProfileFromStats(countryStats);
  const regionProfile = buildProfileFromStats(regionStats);
  const decadeProfile = buildProfileFromStats(decadeStats);
  const keywordProfile = buildProfileFromStats(keywordStats);
  const collectionProfile = buildProfileFromStats(collectionStats);

  cachedTasteModel = {
    usedRatings: ratings.length,
    genreStats,
    genreProfile,
    directorStats,
    directorProfile,
    writerStats,
    writerProfile,
    countryStats,
    countryProfile,
    regionStats,
    regionProfile,
    decadeStats,
    decadeProfile,
    keywordStats,
    keywordProfile,
    collectionStats,
    collectionProfile
  };

  saveDerivedCacheToDisk();
  return cachedTasteModel;
}

/* ---------------------------------------------------
   5. OVERLAP / REWATCH DETAILS
--------------------------------------------------- */

async function buildOverlapDetails() {
  if (cachedOverlapDetails) return cachedOverlapDetails;

  const detailed = [];

  for (const item of overlapItems) {
    try {
      const movie = await getMovieDetailsForItem(item);
      const genres = movie.genres || [];

      detailed.push({
        title: movie.title || movie.name,
        year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
        tmdbId: movie.id,
        posterPath: movie.poster_path,
        genres: genres.map(g => g.name),
        tmdbRating: movie.vote_average,
        userRating: item.rating,
        letterboxdUrl: item.url
      });
    } catch (err) {
      console.warn(`Failed to fetch overlap details for "${item.title}": ${err.message}`);
    }
  }

  cachedOverlapDetails = detailed;
  saveDerivedCacheToDisk();
  return detailed;
}

/* ---------------------------------------------------
   6. MULTI-FACTOR RECOMMENDATIONS
--------------------------------------------------- */

// Helper: compute average affinity given a list of keys and a profile
function affinityFromProfile(keys, profile) {
  if (!keys || !keys.length) return 0;
  let sum = 0;
  let count = 0;
  keys.forEach(k => {
    if (profile[k] !== undefined) {
      sum += profile[k];
      count += 1;
    }
  });
  if (!count) return 0;
  return sum / count;
}

// Helper: normalize rating (Letterboxd style 0–5) to 0–1
function normalizeUserRating(r) {
  if (!r || isNaN(r)) return 0;
  return Math.max(0, Math.min(1, r / 5));
}

// Helper: normalize TMDb rating (0–10) to 0–1
function normalizeTmdbRating(r) {
  if (!r || isNaN(r)) return 0;
  return Math.max(0, Math.min(1, r / 10));
}

async function calculateRecommendations() {
  if (cachedRecommendations) return cachedRecommendations;

  if (!ratings.length || !watchlist.length) {
    cachedRecommendations = {
      recommendations: [],
      usedRatings: 0,
      usedWatchlist: 0
    };
    saveDerivedCacheToDisk();
    return cachedRecommendations;
  }

  const taste = await buildTasteModel();
  const {
    genreProfile,
    directorProfile,
    writerProfile,
    countryProfile,
    regionProfile,
    decadeProfile,
    keywordProfile,
    collectionProfile
  } = taste;

  console.log(`Calculating multi-factor recommendations for ALL ${watchlist.length} watchlist titles...`);

  const recs = [];

  for (const item of watchlist) {
    try {
      const movie = await getMovieDetailsForItem(item);
      const meta = movie.__meta || {};
      const genres = movie.genres || [];

      // 1) Genre affinity (original feature, still exposed as userGenreScore)
      let genreSum = 0;
      let genreCount = 0;
      genres.forEach(g => {
        const gScore = genreProfile[g.id];
        if (gScore !== undefined) {
          genreSum += gScore;
          genreCount += 1;
        }
      });
      const userGenreScoreRaw = genreCount > 0 ? genreSum / genreCount : 0;   // 0–5
      const userGenreScoreNorm = normalizeUserRating(userGenreScoreRaw);      // 0–1

      // 2) Director & writer affinity
      const directors = meta.directors || [];
      const writers = meta.writers || [];
      const directorAffinityRaw = affinityFromProfile(directors, directorProfile); // 0–5
      const writerAffinityRaw = affinityFromProfile(writers, writerProfile);       // 0–5
      const directorAffinity = normalizeUserRating(directorAffinityRaw);
      const writerAffinity = normalizeUserRating(writerAffinityRaw);

      // 3) Country & region affinity
      const countryCodes = (meta.countries || []).map(c => c.code).filter(Boolean);
      const regions = (meta.countries || []).map(c => c.region).filter(Boolean);

      const countryAffinityRaw = affinityFromProfile(countryCodes, countryProfile); // 0–5
      const regionAffinityRaw = affinityFromProfile(regions, regionProfile);        // 0–5

      const countryAffinity = normalizeUserRating(countryAffinityRaw);
      const regionAffinity = normalizeUserRating(regionAffinityRaw);
      const countryRegionAffinity = (countryAffinity + regionAffinity) / 2;         // 0–1

      // 4) Decade affinity
      const decadeKey = meta.decade != null ? String(meta.decade) : null;
      const decadeAffinityRaw = decadeKey && decadeProfile[decadeKey] !== undefined
        ? decadeProfile[decadeKey]
        : 0;
      const decadeAffinity = normalizeUserRating(decadeAffinityRaw);

      // 5) Keyword / tone affinity
      const keywordKeys = (meta.keywords || []).map(k => k.toLowerCase());
      const keywordAffinityRaw = affinityFromProfile(keywordKeys, keywordProfile);
      const keywordAffinity = normalizeUserRating(keywordAffinityRaw);

      // 6) Collection affinity
      let collectionAffinityRaw = 0;
      if (meta.collectionId && collectionProfile[meta.collectionId] !== undefined) {
        collectionAffinityRaw = collectionProfile[meta.collectionId];
      }
      const collectionAffinity = normalizeUserRating(collectionAffinityRaw);

      // 7) TMDb rating
      const tmdbScoreNorm = normalizeTmdbRating(movie.vote_average || 0);

      // 8) Combine all factors into a final score
      // Weights chosen to emphasize directors + tone + genre, but still consider other axes
      const finalScore =
        0.15 * userGenreScoreNorm +
        0.20 * directorAffinity +
        0.10 * writerAffinity +
        0.20 * keywordAffinity +
        0.10 * countryRegionAffinity +
        0.05 * decadeAffinity +
        0.05 * collectionAffinity +
        0.15 * tmdbScoreNorm;

      recs.push({
        title: movie.title || movie.name,
        year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
        tmdbId: movie.id,
        posterPath: movie.poster_path,
        genres: genres.map(g => g.name),
        tmdbRating: movie.vote_average,
        // breakdown for debugging / explanation
        userGenreScore: Number(userGenreScoreRaw.toFixed(2)),      // original 0–5 scale
        directorAffinity: Number(directorAffinity.toFixed(3)),
        writerAffinity: Number(writerAffinity.toFixed(3)),
        keywordAffinity: Number(keywordAffinity.toFixed(3)),
        countryRegionAffinity: Number(countryRegionAffinity.toFixed(3)),
        decadeAffinity: Number(decadeAffinity.toFixed(3)),
        collectionAffinity: Number(collectionAffinity.toFixed(3)),
        tmdbScoreNorm: Number(tmdbScoreNorm.toFixed(3)),
        predictedScore: Number(finalScore.toFixed(3)),             // main score used for ranking
        letterboxdUrl: item.url,
        overview: movie.overview
      });
    } catch (err) {
      console.warn(`Failed to fetch details for watchlist title "${item.title}": ${err.message}`);
    }
  }

  // Sort descending by predictedScore
  recs.sort((a, b) => b.predictedScore - a.predictedScore);

  cachedRecommendations = {
    recommendations: recs,
    usedRatings: ratings.length,
    usedWatchlist: watchlist.length
  };

  saveDerivedCacheToDisk();
  return cachedRecommendations;
}

/* ---------------------------------------------------
   7. STATIC FRONTEND
--------------------------------------------------- */

app.use(express.static(path.join(__dirname, 'public')));

/* ---------------------------------------------------
   8. API ROUTES
--------------------------------------------------- */

app.get('/api', (req, res) => {
  res.json({
    message: 'Taste Matcher API is running (multi-factor taste model)',
    note: 'Using full ratings.csv for an extended taste model + full watchlist.csv with rewatches removed. TMDb metadata and taste model are cached on disk.',
    endpoints: [
      'GET /api/ratings',
      'GET /api/watchlist',
      'GET /api/overlap',
      'GET /api/genre-profile',
      'GET /api/genre-titles/:genreId',
      'GET /api/recommendations'
    ]
  });
});

app.get('/api/ratings', (req, res) => {
  res.json(ratings);
});

app.get('/api/watchlist', (req, res) => {
  res.json(watchlist);
});

app.get('/api/overlap', async (req, res) => {
  try {
    const items = await buildOverlapDetails();
    res.json({
      count: overlapItems.length,
      totalRatings: ratings.length,
      totalWatchlistAfterRemoval: watchlist.length,
      items
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build overlap details' });
  }
});

// Expose the full taste model (for debug / viva)
app.get('/api/genre-profile', async (req, res) => {
  try {
    const taste = await buildTasteModel();
    res.json(taste);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build taste model' });
  }
});

app.get('/api/genre-titles/:genreId', async (req, res) => {
  const genreId = parseInt(req.params.genreId, 10);
  if (isNaN(genreId)) {
    return res.status(400).json({ error: 'Invalid genre id' });
  }

  try {
    // ensure taste model is built so we have fresh TMDb cache
    await buildTasteModel();

    const items = [];

    for (const item of ratings) {
      try {
        const movie = await getMovieDetailsForItem(item);
        const genres = movie.genres || [];
        if (!genres.some(g => g.id === genreId)) continue;

        items.push({
          title: movie.title || movie.name,
          year: (movie.release_date || movie.first_air_date || '').slice(0, 4) || null,
          tmdbId: movie.id,
          posterPath: movie.poster_path,
          genres: genres.map(g => g.name),
          tmdbRating: movie.vote_average,
          userRating: item.rating,
          letterboxdUrl: item.url
        });
      } catch (err) {
        console.warn(`Failed to fetch details for genre-titles "${item.title}": ${err.message}`);
      }
    }

    res.json({
      genreId,
      count: items.length,
      items
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to build list of titles for this genre' });
  }
});

app.get('/api/recommendations', async (req, res) => {
  try {
    const { recommendations, usedRatings, usedWatchlist } = await calculateRecommendations();
    res.json({
      totalRatings: ratings.length,
      totalWatchlist: watchlist.length,
      overlapCount: overlapItems.length,
      usedRatings,
      usedWatchlist,
      recommendations
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to calculate recommendations' });
  }
});

/* ---------------------------------------------------
   9. STARTUP
--------------------------------------------------- */

// 1) Load caches from disk (if any)
loadMovieCacheFromDisk();
loadDerivedCacheFromDisk();

// 2) Load CSV data and overlap info
loadAllData();

app.listen(PORT, () => {
  console.log(`✅ Taste Matcher server listening on http://localhost:${PORT}`);
  console.log('Hint: delete the "cache" folder if you change ratings.csv or watchlist.csv or upgrade the taste model and want to rebuild everything.');
});
